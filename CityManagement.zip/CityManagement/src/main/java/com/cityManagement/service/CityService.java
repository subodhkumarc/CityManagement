package com.cityManagement.service;

import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.cityManagement.entity.CityInfo;
import com.cityManagement.repository.CityRepository;
/**
 * 
 * @author subodhkumar.chellar
 * @version 1.0
 * @since 13-09-20
 * 
 */

@Service
public class CityService {

	@Autowired
	private CityRepository cityRepository;
	
	public List<CityInfo> getAllCities(){
		return cityRepository.findAll();
		
	}
	
	public List<CityInfo> searchCities(String startDate, String endDate){
		return cityRepository.findByStartAndEndDate(startDate, endDate);
		
	}
}
