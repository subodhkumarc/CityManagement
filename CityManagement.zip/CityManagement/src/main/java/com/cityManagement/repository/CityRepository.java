package com.cityManagement.repository;

import java.util.List;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;
import com.cityManagement.entity.CityInfo;

/**
 * 
 * @author subodhkumar.chellar
 * @version 1.0
 * @since 13-09-20
 * 
 */

@Repository
public interface CityRepository extends JpaRepository<CityInfo, Integer>{

	@Query("Select ci from CityInfo ci where ci.start_date>=:startDate and ci.end_date<=:endDate")
	public List<CityInfo> findByStartAndEndDate(@Param("startDate") String startDate,@Param("endDate") String endDate);
}
