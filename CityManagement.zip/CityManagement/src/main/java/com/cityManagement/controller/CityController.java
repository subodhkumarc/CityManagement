package com.cityManagement.controller;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RestController;

import com.cityManagement.entity.CityInfo;
import com.cityManagement.service.CityService;
/**
 * 
 * @author subodhkumar.chellar
 * @version 1.0
 * @since 13-09-20
 * 
 */
@RestController
public class CityController {

	@Autowired
	CityService cityService;
	
	/*To fetch all cities*/
	@GetMapping(path="/cities")
	public List<CityInfo> getAllCities(){
		return cityService.getAllCities();
	}
	
	/*To fetch cities based on startDate and endDate*/
	@GetMapping(path="/cities/{start_date}/{end_date}")
	public List<CityInfo> searchCitiesByDate(@PathVariable("start_date") Date startDate, @PathVariable("end_date") Date endDate){
		SimpleDateFormat simpleDateFormat = new SimpleDateFormat("MM/dd/yyyy");
		return cityService.searchCities(simpleDateFormat.format(startDate), simpleDateFormat.format(endDate));
	}
	
}
