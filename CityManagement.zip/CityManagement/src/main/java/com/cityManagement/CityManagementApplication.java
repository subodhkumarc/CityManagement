package com.cityManagement;

import java.io.IOException;
import java.io.InputStream;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

import com.cityManagement.entity.CityInfo;
import com.cityManagement.repository.CityRepository;
import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;

/**
 * 
 * @author subodhkumar.chellar
 * @version 1.0
 * @since 13-09-20
 * 
 */

@SpringBootApplication
public class CityManagementApplication implements CommandLineRunner{

	public static void main(String[] args) {
		SpringApplication.run(CityManagementApplication.class, args);
	}

	@Autowired
	CityRepository cityRepository;
	
	@Override
	public void run(String... args) throws Exception {
		// read json and write to h2 db
					ObjectMapper mapper = new ObjectMapper();
					TypeReference<List<CityInfo>> typeReference = new TypeReference<List<CityInfo>>(){};
					InputStream inputStream = TypeReference.class.getResourceAsStream("/json/data.json");
					try {
						List<CityInfo> users = mapper.readValue(inputStream,typeReference);
						cityRepository.saveAll(users);
						System.out.println("Users Saved!");
					} catch (IOException e){
						System.out.println("Unable to save users: " + e.getMessage());
					}
	}

}
