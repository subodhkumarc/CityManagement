package com.cityManagement;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CityManagementApplicationTests {

	@Test
	void contextLoads() {
	}

}
